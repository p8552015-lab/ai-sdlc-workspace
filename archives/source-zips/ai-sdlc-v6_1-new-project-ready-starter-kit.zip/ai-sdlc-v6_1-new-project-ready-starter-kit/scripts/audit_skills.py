#!/usr/bin/env python3
from pathlib import Path
import sys, re, yaml

ROOT = Path(__file__).resolve().parents[1]
MAP = ROOT / 'pipeline' / 'skill-map.yml'
ADDY = ROOT / 'skills' / 'external' / 'addyosmani-agent-skills' / 'skills'
COMPANY = ROOT / 'skills' / 'company'

required_sections = ['Overview', 'When to Use', 'Process', 'Rationalizations', 'Red Flags', 'Verification']

def load_yaml(path):
    try:
        import yaml
        return yaml.safe_load(path.read_text(encoding='utf-8'))
    except Exception as e:
        print(f'ERROR: failed to read {path}: {e}')
        sys.exit(2)

def check_skill(path):
    if not path.exists():
        return [f'missing {path}']
    text = path.read_text(encoding='utf-8', errors='replace')
    errors = []
    for s in required_sections:
        if not re.search(rf'^#{{1,3}}\s+{re.escape(s)}\b', text, re.M):
            errors.append(f'{path}: missing section {s}')
    if not text.startswith('---'):
        errors.append(f'{path}: missing YAML frontmatter')
    return errors

data = load_yaml(MAP)
errors = []
for stage, cfg in data.get('stages', {}).items():
    for item in cfg.get('required', []):
        skill = item.get('skill')
        source = item.get('source')
        if not skill: continue
        base = ADDY if source == 'addyosmani_agent_skills' else COMPANY
        if source == 'addyosmani_agent_skills':
            errors += check_skill(base / skill / 'SKILL.md')
        elif source == 'company':
            errors += check_skill(base / skill / 'SKILL.md')

if errors:
    print('\n'.join(errors))
    sys.exit(1)
print('Skill audit passed')
